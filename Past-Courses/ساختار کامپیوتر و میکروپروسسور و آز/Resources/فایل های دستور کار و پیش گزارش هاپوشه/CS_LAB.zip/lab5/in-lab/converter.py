import sys

from pdf2image import convert_from_path

# Path to your input PDF
input_pdf_path = sys.argv[1]
# Convert each page to an image (by default PNG)
images = convert_from_path(input_pdf_path, dpi=300)

# Save each page as an image
for i, image in enumerate(images):
    image.save(f'page_{i + 1}.png', 'PNG')

