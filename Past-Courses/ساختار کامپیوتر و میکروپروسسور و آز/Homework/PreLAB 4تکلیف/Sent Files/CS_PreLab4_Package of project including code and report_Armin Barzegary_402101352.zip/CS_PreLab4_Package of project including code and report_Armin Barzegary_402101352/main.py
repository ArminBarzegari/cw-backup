from machine import Pin
import time

led = Pin(25, Pin.OUT)

# Ask the user for inputs over the serial terminal
on_time_ms = int(input("Enter On time (ms): "))
off_time_ms = int(input("Enter Off time (ms): "))

print("Starting adjustable blink...")

# Blink continuously
while True:
    led.value(1)
    time.sleep_ms(on_time_ms)
    
    led.value(0)
    time.sleep_ms(off_time_ms)